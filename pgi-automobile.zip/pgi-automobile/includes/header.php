<?php
session_start();
require_once __DIR__ . '/../config/database.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>PGI Automobile</title>
    <link rel="stylesheet" href="/pgi-automobile/assets/css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                🚗 PGI Automobile
            </div>
            <ul class="nav-links">
                <li><a href="/pgi-automobile/index.php">🏠 Accueil</a></li>
                <li><a href="/pgi-automobile/modules/vehicules/liste.php">🚙 Véhicules</a></li>
                <li><a href="/pgi-automobile/modules/clients/liste.php">👥 Clients</a></li>
                <li><a href="/pgi-automobile/modules/ventes/liste.php">💰 Ventes</a></li>
                <li><a href="/pgi-automobile/modules/stock/inventaire.php">📦 Stock</a></li>
                <li><a href="/pgi-automobile/modules/statistiques/dashboard.php">📊 Stats</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">