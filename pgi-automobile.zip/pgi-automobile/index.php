<?php
$page_title = "Tableau de bord";
include 'includes/header.php';

// Statistiques
$stmt = $pdo->query("SELECT COUNT(*) as total FROM vehicules WHERE statut = 'stock'");
$vehicules_stock = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM clients");
$total_clients = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM ventes WHERE MONTH(date_vente) = MONTH(CURRENT_DATE())");
$ventes_mois = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT SUM(prix_vente) as total FROM ventes WHERE MONTH(date_vente) = MONTH(CURRENT_DATE())");
$ca_mois = $stmt->fetch()['total'] ?? 0;

// Dernières ventes
$stmt = $pdo->query("
    SELECT v.*, ve.marque, ve.modele, c.nom, c.prenom 
    FROM ventes v
    JOIN vehicules ve ON v.vehicule_id = ve.id
    JOIN clients c ON v.client_id = c.id
    ORDER BY v.date_vente DESC
    LIMIT 5
");
$dernieres_ventes = $stmt->fetchAll();

// Véhicules en stock
$stmt = $pdo->query("
    SELECT * FROM vehicules 
    WHERE statut = 'stock' 
    ORDER BY date_arrivee DESC 
    LIMIT 6
");
$vehicules_recents = $stmt->fetchAll();
?>

<h1 style="color: white; text-align: center; margin-bottom: 2rem;">
    🚗 Tableau de Bord - PGI Automobile
</h1>

<!-- Statistiques -->
<div class="stats-grid">
    <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="stat-icon">🚙</div>
        <div class="stat-value"><?php echo $vehicules_stock; ?></div>
        <div class="stat-label">Véhicules en stock</div>
    </div>
    
    <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
        <div class="stat-icon">👥</div>
        <div class="stat-value"><?php echo $total_clients; ?></div>
        <div class="stat-label">Clients actifs</div>
    </div>
    
    <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
        <div class="stat-icon">💰</div>
        <div class="stat-value"><?php echo $ventes_mois; ?></div>
        <div class="stat-label">Ventes ce mois</div>
    </div>
    
    <div class="stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
        <div class="stat-icon">📈</div>
        <div class="stat-value"><?php echo formatPrice($ca_mois); ?></div>
        <div class="stat-label">CA du mois</div>
    </div>
</div>

<!-- Dernières ventes -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">💼 Dernières Ventes</h2>
        <a href="modules/ventes/liste.php" class="btn btn-primary btn-sm">Voir tout</a>
    </div>
    
    <?php if (count($dernieres_ventes) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Véhicule</th>
                        <th>Client</th>
                        <th>Prix</th>
                        <th>Paiement</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dernieres_ventes as $vente): ?>
                        <tr>
                            <td><?php echo formatDate($vente['date_vente']); ?></td>
                            <td>🚗 <?php echo escape($vente['marque'] . ' ' . $vente['modele']); ?></td>
                            <td><?php echo escape($vente['nom'] . ' ' . $vente['prenom']); ?></td>
                            <td><strong><?php echo formatPrice($vente['prix_vente']); ?></strong></td>
                            <td><span class="badge badge-stock"><?php echo ucfirst($vente['mode_paiement']); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p style="text-align: center; color: #999;">Aucune vente enregistrée</p>
    <?php endif; ?>
</div>

<!-- Véhicules récents en stock -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">🚙 Véhicules en Stock</h2>
        <a href="modules/vehicules/liste.php" class="btn btn-primary btn-sm">Voir tout</a>
    </div>
    
    <?php if (count($vehicules_recents) > 0): ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Véhicule</th>
                        <th>Année</th>
                        <th>Carburant</th>
                        <th>Prix</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vehicules_recents as $vehicule): ?>
                        <tr>
                            <td><span class="car-type-<?php echo $vehicule['type_vehicule']; ?>"></span></td>
                            <td><strong><?php echo escape($vehicule['marque'] . ' ' . $vehicule['modele']); ?></strong></td>
                            <td><?php echo $vehicule['annee']; ?></td>
                            <td><?php echo ucfirst($vehicule['carburant']); ?></td>
                            <td><?php echo formatPrice($vehicule['prix_vente']); ?></td>
                            <td><span class="badge badge-<?php echo $vehicule['statut']; ?>"><?php echo ucfirst($vehicule['statut']); ?></span></td>
                            <td>
                                <a href="modules/vehicules/modifier.php?id=<?php echo $vehicule['id']; ?>" class="btn btn-warning btn-sm">✏️</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p style="text-align: center; color: #999;">Aucun véhicule en stock</p>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>